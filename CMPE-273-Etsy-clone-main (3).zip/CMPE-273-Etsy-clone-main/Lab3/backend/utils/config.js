const config = {
  secret: "cmpe273_secret_key",
  frontendURL: "http://localhost:3000",
};

module.exports = config;
