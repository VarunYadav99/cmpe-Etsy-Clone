const config = {
  secret: "cmpe273_secret_key",
  frontendURL: "http://localhost:3000",
  backendURL: "http://localhost:3001",
};

module.exports = config;
