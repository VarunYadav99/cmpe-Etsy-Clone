export const serverUrl = "http://localhost:3001";
