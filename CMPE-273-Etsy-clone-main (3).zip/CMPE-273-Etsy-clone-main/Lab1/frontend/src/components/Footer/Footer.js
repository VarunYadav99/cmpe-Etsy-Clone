import React from "react";

export default function Footer() {
  return (
    <>
      <br />
      <br />

      <footer className="footer mt-auto py-2">
        <div className="container">
          <span className=" pb-3 footer-text">
            Change Currency:{" "}
            <select>
              <option>$</option>
              <option>₹</option>
              <option>€</option>
            </select>
          </span>
        </div>
      </footer>
    </>
  );
}
